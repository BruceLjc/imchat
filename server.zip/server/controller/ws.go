package controller

import (
	"app/service"
	"log"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	redis "github.com/go-redis/redis/v8"
	"github.com/gorilla/websocket"
)

// 定义一个WebSocket升级器
var upgrader = websocket.Upgrader{
	CheckOrigin: func(r *http.Request) bool {
		return true
	},
}

func Acc(c *gin.Context) {
	id := c.Query("id")

	conn, err := upgrader.Upgrade(c.Writer, c.Request, nil)
	defer conn.Close()

	if err != nil {
		c.String(400, err.Error())
		return
	}
	rdb := service.Rdb{}
	for {
		// 从 Redis 中读取消息
		str, err := rdb.RPop(id)
		if err == redis.Nil {
			// 没有更多消息，等待一段时间后继续
			time.Sleep(time.Millisecond * 100)
			continue
			// conn.WriteMessage(websocket.TextMessage, []byte("空"))
			// break
		} else if err != nil {
			log.Printf("Failed to RPop from Redis: %v", err)
			break
		}

		// 发送消息到 WebSocket 客户端
		err = conn.WriteMessage(websocket.TextMessage, []byte(str))
		if err != nil {
			log.Printf("Failed to write message to WebSocket: %v", err)
			break
		}

		time.Sleep(time.Millisecond * 100)
	}
}
