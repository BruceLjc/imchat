package controller

import (
	"app/model"
	"app/service"
	"context"
	"encoding/json"

	"github.com/gin-gonic/gin"
)

func Send(c *gin.Context) {
	m := model.SendReq{}
	if c.ShouldBindJSON(&m) != nil {
		c.String(400, "not req")
		return
	}

	//异步发送消息到队列
	r := service.RabbitMQ{}
	ch, err := r.Channel()
	if err != nil {
		c.String(200, err.Error())
	}
	ctx := context.Background()
	body, _ := json.Marshal(m)
	err = r.Publish(ctx, ch, "chat_task_queue", body)

	if err != nil {
		c.String(400, err.Error())
		return
	}
	c.String(200, "ok")
}
