package router

import (
	"app/controller"

	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
)

func Init() {
	r := gin.Default()
	r.Use(cors.Default())

	r.POST("/send", controller.Send)
	r.GET("/acc", controller.Acc)
	r.Run()
}
