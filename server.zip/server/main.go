package main

import (
	"app/service"
	"app/router"
)

func main() {
	service.Init()
	router.Init()
}