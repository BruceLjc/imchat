package model

type SendReq struct {
	SendId string `json:"sendId"`
	AccId  string `json:"accId"`
	Msg    string `json:"msg"`
}
