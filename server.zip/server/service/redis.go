package service

type Rdb struct {
}

func (r *Rdb) LPush(key string, values ...interface{}) error {
	return Redis.LPush(Redis.Context(), key, values).Err()
}

func (r *Rdb) GetAllList(key string) ([]string, error) {
	return Redis.LRange(Redis.Context(), key, 0, -1).Result()
}

func (r *Rdb) RPop(key string) (string, error) {
	return Redis.RPop(Redis.Context(), key).Result()
}
