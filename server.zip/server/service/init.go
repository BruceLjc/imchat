package service

import (
	"context"
	"encoding/json"
	"fmt"
	"log"

	"app/config"

	"github.com/go-redis/redis/v8"
	amqp "github.com/rabbitmq/amqp091-go"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
)

var (
	Cfg   *config.Config
	DB    *gorm.DB
	Redis *redis.Client
	Amqp  *amqp.Connection
	err   error
)

func Init() {
	Cfg = config.LoadConfig()
	initMySQL()
	initRedis()
	initRabbitMQ()
}

func initMySQL() {
	dsn := Cfg.MySQL.DSN
	DB, err = gorm.Open(mysql.Open(dsn), &gorm.Config{})
	if err != nil {
		log.Fatal("failed to connect database:", err)
	}
	fmt.Println("MySQL connected")
}

func initRabbitMQ() {
	dsn := Cfg.RabbitMQ.URL
	Amqp, err = amqp.Dial(dsn)
	if err != nil {
		log.Fatal("Failed to connect to RabbitMQ:", err)
	}
	fmt.Println("RabbitMQ connected")

	//初始化队列数量，消费消息 ,推动到redis
	r := RabbitMQ{}
	ch, err := r.Channel()
	r.failOnError(err, "初始化channel失败")
	for i := 0; i < Cfg.RabbitMQ.Num; i++ {
		go func(i int) {
			q, err := r.Queue(ch, "chat_task_queue")
			r.failOnError(err, "初始化rabbitmq队列失败")
			msgs, err := r.Consume(ch, q.Name)
			r.failOnError(err, "初始化rabbitmq，获取消息失败")
			for v := range msgs {
				//解析消息，推送到制定队列
				var m map[string]interface{}
				err := json.Unmarshal(v.Body, &m)
				if err != nil {
					log.Println("解析消息失败: ", err)
					continue
				}
				accId, ok := m["accId"].(string)
				if !ok {
					log.Println("找不到sendId ", err)
					continue
				}
				//推动redis中sendId队列
				rdb := Rdb{}
				err = rdb.LPush(accId, v.Body)
				if err != nil {
					log.Println("推送redis失败， ", err)
				}
				fmt.Println(i, "推送成功")
			}
		}(i)
	}
}

func initRedis() {

	var ctx = context.Background()

	Redis = redis.NewClient(&redis.Options{
		Addr:     Cfg.Redis.Addr,
		Password: Cfg.Redis.Password, // no password set
		DB:       Cfg.Redis.DB,       // use default DB
	})

	_, err := Redis.Ping(ctx).Result()
	if err != nil {
		log.Fatal("Failed to connect to Redis:", err)
	}
	fmt.Println("Redis connected")
}
