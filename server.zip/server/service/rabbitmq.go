package service

import (
	"context"
	"log"

	amqp "github.com/rabbitmq/amqp091-go"
)

type RabbitMQ struct {
}

func (r *RabbitMQ) failOnError(err error, msg string) {
	if err != nil {
		log.Panicf("%s: %s", msg, err)
	}
}

func (r *RabbitMQ) Channel() (*amqp.Channel, error) {
	return Amqp.Channel()
}

func (r *RabbitMQ) Queue(ch *amqp.Channel, queue_name string) (amqp.Queue, error) {
	return ch.QueueDeclare(
		queue_name, // name
		true,       // durable
		false,      // delete when unused
		false,      // exclusive
		false,      // no-wait
		nil,        // arguments
	)
}

func (r *RabbitMQ) ChQos(ch *amqp.Channel) {
	ch.Qos(
		1,     // prefetch count
		0,     // prefetch size
		false, // global
	)
}

func (r *RabbitMQ) Consume(ch *amqp.Channel, queue_name string) (<-chan amqp.Delivery, error) {
	return ch.Consume(
		queue_name, // queue
		"",         // consumer
		true,       // auto-ack
		false,      // exclusive
		false,      // no-local
		false,      // no-wait
		nil,        // args
	)
}

func (r *RabbitMQ) Publish(ctx context.Context, ch *amqp.Channel, queue_name string, body []byte) error {
	return ch.PublishWithContext(ctx,
		"",         // exchange
		queue_name, // routing key
		false,      // mandatory
		false,
		amqp.Publishing{
			DeliveryMode: amqp.Persistent,
			ContentType:  "text/plain",
			Body:         []byte(body),
		})
}
