package config

import (
	"io/ioutil"
	"log"

	"gopkg.in/yaml.v2"
)

type Config struct {
	MySQL struct {
		DSN string `yaml:"dsn"`
	} `yaml:"mysql"`
	RabbitMQ struct {
		URL string `yaml:"url"`
		Num int    `yaml:"num"`
	} `yaml:"rabbitmq"`
	Redis struct {
		Addr     string `yaml:"addr"`
		Password string `yaml:"password"`
		DB       int    `yaml:"db"`
	} `yaml:"redis"`
}

func LoadConfig() *Config {
	config := &Config{}
	data, err := ioutil.ReadFile("./config/config.yaml")
	if err != nil {
		log.Fatal(err)
	}
	err = yaml.Unmarshal(data, config)
	if err != nil {
		log.Fatal(err)
	}
	return config
}
